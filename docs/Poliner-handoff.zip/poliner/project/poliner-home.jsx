// poliner-home.jsx — Home Dashboard

function HomeScreen({ onNavigate }) {
  const disponibili = UOVA.filter(u => u.stato === 'disponibile').length;
  const oggiUova = UOVA.filter(u => u.data === dataStr(oggi)).length;
  const gallineCount = GALLINE.filter(g => g.tipo === 'gallina').length;

  // Alerts
  const alerts = [];
  MANUTENZIONI_TIPI.forEach(tipo => {
    const stato = statoManutenzione(tipo.id);
    const giorni = giorniDaUltimaManutenzione(tipo.id);
    if (stato === 'scaduta') {
      alerts.push({ icon: '⚠️', title: `${tipo.nome} in ritardo`, subtitle: `Sono passati ${giorni} giorni`, color: '#E8678A', action: () => onNavigate('maintenance') });
    } else if (stato === 'in_scadenza') {
      alerts.push({ icon: '🔔', title: `${tipo.nome} tra poco`, subtitle: `Ultimo intervento ${giorni} giorni fa`, color: '#FFE07A', action: () => onNavigate('maintenance') });
    }
  });
  // Health alerts
  GALLINE.forEach(g => {
    if (g.salute === 'problema') {
      alerts.push({ icon: '❤️‍🩹', title: `${g.nome} ha un problema`, subtitle: g.problemaAttivo, color: '#E8678A', action: () => onNavigate('chicken-detail', g.id) });
    }
    if (g.inMuta) {
      const giorniMuta = Math.floor((oggi - new Date(g.inizioMuta)) / (1000*60*60*24));
      alerts.push({ icon: '🪶', title: `${g.nome} è in muta`, subtitle: `Da ${giorniMuta} giorni`, color: '#E8DAFF', action: () => onNavigate('chicken-detail', g.id) });
    }
  });

  const homeStyles = {
    greeting: { padding: '20px 16px 0', },
    greetingText: { fontFamily: 'Lora, serif', fontSize: 24, fontWeight: 700, color: 'var(--text)', lineHeight: 1.3, },
    greetingSub: { fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 },
  };

  const days = ['Domenica','Lunedì','Martedì','Mercoledì','Giovedì','Venerdì','Sabato'];
  const months = ['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
  const dateStr = `${days[oggi.getDay()]} ${oggi.getDate()} ${months[oggi.getMonth()]}`;

  return (
    <ScreenContainer pad={false}>
      {/* Greeting */}
      <div style={homeStyles.greeting}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={homeStyles.greetingText}>Il Pollaio di Fiocca</div>
            <div style={homeStyles.greetingSub}>{dateStr}</div>
          </div>
          <button className="btn-icon" onClick={() => onNavigate('notifications')} style={{ marginTop: 4 }}>
            <IconBell size={22} color="var(--text-secondary)" />
          </button>
        </div>
      </div>

      <div style={{ padding: '0 16px' }}>
        {/* Weather widget */}
        <div className="card" style={{ marginTop: 16, background: 'linear-gradient(135deg, #A8D1FF22, #A8D1FF11)', border: '1px solid #A8D1FF44' }}
          onClick={() => onNavigate('weather')}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 36 }}>{METEO.attuale.icona}</span>
              <div>
                <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--text)' }}>{METEO.attuale.temp}°C</div>
                <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{METEO.attuale.condizione}</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 12, fontSize: 12, color: 'var(--text-secondary)' }}>
              {METEO.previsioni.slice(1, 3).map((p, i) => (
                <div key={i} style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 20, marginBottom: 2 }}>{p.pomeriggio.icona}</div>
                  <div style={{ fontWeight: 600 }}>{p.pomeriggio.temp}°</div>
                  <div>{p.giorno}</div>
                </div>
              ))}
            </div>
          </div>
          {METEO.consiglio && (
            <div style={{ marginTop: 10, padding: '8px 12px', background: '#A8D1FF22', borderRadius: 10, fontSize: 13, color: 'var(--text)' }}>
              {METEO.consiglio}
            </div>
          )}
        </div>

        {/* Egg counter + Quick stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
          <div className="card card-clickable" onClick={() => onNavigate('eggs')}
            style={{ background: 'var(--primary-lighter)', textAlign: 'center', border: '1px solid var(--primary-light)' }}>
            <div style={{ fontSize: 36, marginBottom: 4 }}>🥚</div>
            <div style={{ fontSize: 36, fontWeight: 800, color: 'var(--primary)' }}>{disponibili}</div>
            <div style={{ fontSize: 13, color: 'var(--primary)', fontWeight: 600 }}>uova disponibili</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}>+{oggiUova} oggi</div>
          </div>
          <div className="card card-clickable" onClick={() => onNavigate('chickens')}
            style={{ background: '#B5D4B520', textAlign: 'center', border: '1px solid #B5D4B544' }}>
            <div style={{ fontSize: 36, marginBottom: 4 }}>🐔</div>
            <div style={{ fontSize: 36, fontWeight: 800, color: '#5a8a5a' }}>{gallineCount}</div>
            <div style={{ fontSize: 13, color: '#5a8a5a', fontWeight: 600 }}>galline</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}>+1 gallo</div>
          </div>
        </div>

        {/* Quick actions */}
        <SectionTitle>Azioni rapide</SectionTitle>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          {[
            { label: 'Aggiungi\nuovo', icon: '🥚', bg: '#FFE4D0', action: 'add-egg' },
            { label: 'Segnala\npulizia', icon: '🧹', bg: '#B5D4B5', action: 'add-cleaning' },
            { label: 'Nota\nrapida', icon: '📝', bg: '#E8DAFF', action: 'add-note' },
          ].map(a => (
            <button key={a.action} className="card card-clickable"
              onClick={() => onNavigate(a.action)}
              style={{ textAlign: 'center', padding: '16px 8px', border: 'none', cursor: 'pointer', background: '#fff' }}>
              <div style={{ width: 44, height: 44, borderRadius: 14, background: a.bg,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, margin: '0 auto 8px' }}>
                {a.icon}
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', whiteSpace: 'pre-line', lineHeight: 1.3 }}>{a.label}</div>
            </button>
          ))}
        </div>

        {/* Alerts */}
        {alerts.length > 0 && (
          <React.Fragment>
            <SectionTitle>Avvisi</SectionTitle>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {alerts.slice(0, 4).map((a, i) => (
                <AlertCard key={i} icon={a.icon} title={a.title} subtitle={a.subtitle} color={a.color} onClick={a.action} />
              ))}
            </div>
          </React.Fragment>
        )}

        {/* Seasonal tip */}
        <div className="card" style={{ marginTop: 16, background: '#B5D4B515', border: '1px solid #B5D4B544' }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <span style={{ fontSize: 28 }}>{STAGIONALITA.icona}</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text)', marginBottom: 4 }}>Consiglio di stagione</div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{STAGIONALITA.messaggio}</div>
            </div>
          </div>
        </div>

        {/* Weekly production mini chart */}
        <SectionTitle right={
          <button className="btn-text" onClick={() => onNavigate('stats')} style={{ fontSize: 13 }}>Vedi tutto →</button>
        }>Produzione settimanale</SectionTitle>
        <div className="card">
          <MiniBarChart
            data={PRODUZIONE_SETTIMANE.map((s, i) => ({
              value: s.prodotte,
              label: s.settimana.replace('Sett ', ''),
              highlight: i === PRODUZIONE_SETTIMANE.length - 1,
            }))}
            barColor="var(--primary)"
            height={56}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontSize: 12, color: 'var(--text-secondary)' }}>
            <span>Questa settimana: <strong style={{ color: 'var(--text)' }}>{PRODUZIONE_SETTIMANE[PRODUZIONE_SETTIMANE.length-1].prodotte} uova</strong></span>
            <span>Media: <strong style={{ color: 'var(--text)' }}>{Math.round(PRODUZIONE_SETTIMANE.reduce((s,w) => s + w.prodotte, 0) / PRODUZIONE_SETTIMANE.length)}/sett</strong></span>
          </div>
        </div>

        {/* Recent notes */}
        <SectionTitle right={
          <button className="btn-text" onClick={() => onNavigate('notes')} style={{ fontSize: 13 }}>Tutte →</button>
        }>Note recenti</SectionTitle>
        {NOTE.slice(0, 2).map(n => (
          <div key={n.id} className="card" style={{ marginBottom: 8 }} onClick={() => onNavigate('notes')}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 16 }}>{n.tag === 'osservazione' ? '👁️' : n.tag === 'idea' ? '💡' : '🔔'}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>{n.testo}</div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}>{formatData(n.data)}</div>
              </div>
            </div>
          </div>
        ))}

        <div style={{ height: 24 }}></div>
      </div>
    </ScreenContainer>
  );
}

Object.assign(window, { HomeScreen });
