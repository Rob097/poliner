// poliner-chickens.jsx — Chicken list + detail screens

function ChickensListScreen({ onNavigate }) {
  const [search, setSearch] = React.useState('');
  const filtered = GALLINE.filter(g =>
    g.nome.toLowerCase().includes(search.toLowerCase()) ||
    g.razza.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <React.Fragment>
      <Header title="Le tue galline" subtitle={`${GALLINE.filter(g=>g.tipo==='gallina').length} galline e ${GALLINE.filter(g=>g.tipo==='gallo').length} gallo`} />
      <ScreenContainer>
        <div style={{ position: 'relative', marginBottom: 12 }}>
          <IconSearch size={18} color="var(--text-secondary)" style={{ position: 'absolute', left: 14, top: 13 }} />
          <input className="input" placeholder="Cerca per nome o razza..."
            value={search} onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 40 }} />
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {filtered.map(g => {
            const fase = faseProduttiva(g);
            return (
              <ListItem key={g.id}
                onClick={() => onNavigate('chicken-detail', g.id)}
                left={<Avatar emoji={g.avatar} bg={g.avatarBg} size={48} />}
                title={g.nome}
                subtitle={`${g.razza} · ${calcolaEta(g.dataNascita)}`}
                badge={
                  <React.Fragment>
                    {g.salute === 'problema' && <Badge label="❤️‍🩹 Salute" bg="#FFD6E0" color="#c0435a" small />}
                    {g.inMuta && <Badge label="🪶 In muta" bg="#E8DAFF" color="#7b5ea7" small />}
                  </React.Fragment>
                }
                right={
                  g.tipo === 'gallina' ? (
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--primary)' }}>{g.uovaSettimana}</div>
                      <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>uova/sett</div>
                    </div>
                  ) : <IconChevron size={18} color="var(--text-secondary)" />
                }
              />
            );
          })}
        </div>

        <button className="btn-primary" style={{ width: '100%', marginTop: 16 }}
          onClick={() => onNavigate('add-chicken')}>
          <IconPlus size={18} /> Aggiungi animale
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

function ChickenDetailScreen({ chickenId, onBack, onNavigate }) {
  const g = GALLINE.find(c => c.id === chickenId);
  const [activeTab, setActiveTab] = React.useState('info');
  if (!g) return null;

  const fase = faseProduttiva(g);
  const eta = calcolaEta(g.dataNascita);
  const razzaInfo = RAZZE[g.razza];
  const gallinaUova = UOVA.filter(u => u.gallina === g.nome);
  const gallinaTrattamenti = TRATTAMENTI.filter(t => t.animale === g.nome || t.animale === 'Tutto il pollaio');

  const tabs = g.tipo === 'gallina'
    ? [{ value: 'info', label: 'Info' }, { value: 'uova', label: 'Uova' }, { value: 'salute', label: 'Salute' }]
    : [{ value: 'info', label: 'Info' }, { value: 'salute', label: 'Salute' }];

  return (
    <React.Fragment>
      <Header title={g.nome} onBack={onBack} right={
        <button className="btn-icon"><IconEdit size={20} color="var(--text-secondary)" /></button>
      } />

      {/* Hero card */}
      <div style={{ padding: '0 16px' }}>
        <div className="card" style={{ textAlign: 'center', background: g.avatarBg + '33', border: `1px solid ${g.avatarBg}88` }}>
          <div style={{ fontSize: 64, marginBottom: 8 }}>{g.avatar}</div>
          <div style={{ fontFamily: 'Lora, serif', fontSize: 24, fontWeight: 700, color: 'var(--text)' }}>{g.nome}</div>
          <div style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>
            {g.razza} · {g.tipo === 'gallo' ? 'Gallo' : 'Gallina'} · {eta}
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
            {g.salute === 'problema' && <Badge label="❤️‍🩹 Problema salute" bg="#FFD6E0" color="#c0435a" />}
            {g.inMuta && <Badge label={`🪶 In muta da ${Math.floor((oggi - new Date(g.inizioMuta))/(1000*60*60*24))} giorni`} bg="#E8DAFF" color="#7b5ea7" />}
            {fase && <Badge label={fase.label} bg={fase.colore + '44'} color={fase.colore === '#B5D4B5' ? '#3d6b3d' : '#7b5ea7'} />}
          </div>

          {g.tipo === 'gallina' && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 24, marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--border)' }}>
              <StatNumber value={g.uovaSettimana} label="questa settimana" color="var(--primary)" small />
              <StatNumber value={gallinaUova.length} label="totali" small />
              <StatNumber value={gallinaUova.filter(u => u.stato === 'regalato').length} label="regalate" small />
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ padding: '12px 16px 0' }}>
        <SegmentedControl options={tabs} value={activeTab} onChange={setActiveTab} />
      </div>

      <div style={{ padding: '0 16px 24px' }}>
        {activeTab === 'info' && (
          <div style={{ marginTop: 12 }}>
            {/* Breed info */}
            {razzaInfo && razzaInfo.uovaAnno !== '—' && (
              <React.Fragment>
                <SectionTitle>Informazioni razza</SectionTitle>
                <div className="card">
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div><div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Produzione</div><div style={{ fontWeight: 600, fontSize: 14 }}>🥚 {razzaInfo.uovaAnno}/anno</div></div>
                    <div><div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Taglia</div><div style={{ fontWeight: 600, fontSize: 14 }}>📏 {razzaInfo.taglia}</div></div>
                    <div><div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Colore uova</div><div style={{ fontWeight: 600, fontSize: 14 }}>🎨 {razzaInfo.coloreUova}</div></div>
                    <div><div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Temperamento</div><div style={{ fontWeight: 600, fontSize: 14 }}>💛 {razzaInfo.temperamento}</div></div>
                  </div>
                </div>
              </React.Fragment>
            )}

            {/* Personal details */}
            <SectionTitle>Dettagli</SectionTitle>
            <div className="card">
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Colore piumaggio</span>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{g.colore}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Data di nascita</span>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{formatDataLunga(g.dataNascita)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Età</span>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{eta}</span>
                </div>
                {fase && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Fase produttiva</span>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>{fase.label}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Notes */}
            {g.note && (
              <React.Fragment>
                <SectionTitle>Note</SectionTitle>
                <div className="card">
                  <p style={{ fontSize: 14, color: 'var(--text)', lineHeight: 1.6, margin: 0 }}>{g.note}</p>
                </div>
              </React.Fragment>
            )}

            {g.salute === 'problema' && (
              <React.Fragment>
                <SectionTitle>Problema attivo</SectionTitle>
                <div className="card" style={{ borderLeft: '4px solid #E8678A' }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>❤️‍🩹 {g.problemaAttivo}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Stato: in corso</div>
                </div>
              </React.Fragment>
            )}
          </div>
        )}

        {activeTab === 'uova' && (
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 20, marginBottom: 16 }}>
              <StatNumber value={g.uovaSettimana} label="questa settimana" color="var(--primary)" />
              <StatNumber value={gallinaUova.length} label="totali" />
            </div>

            <SectionTitle>Ultime uova</SectionTitle>
            {gallinaUova.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {gallinaUova.slice(0, 8).map(u => (
                  <div key={u.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px' }}>
                    <span style={{ fontSize: 20 }}>🥚</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 600 }}>{formatData(u.data)}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{u.nido}{u.note ? ` · ${u.note}` : ''}</div>
                    </div>
                    <Badge label={u.stato === 'disponibile' ? 'Disponibile' : u.stato === 'consumato' ? 'Consumato' : `Regalato`}
                      bg={u.stato === 'disponibile' ? '#B5D4B533' : u.stato === 'consumato' ? '#F0EDE8' : '#FFE4D044'}
                      color={u.stato === 'disponibile' ? '#3d6b3d' : u.stato === 'consumato' ? 'var(--text-secondary)' : '#b87333'}
                      small />
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState icon="🥚" title="Nessun uovo ancora" subtitle="Le uova di questa gallina appariranno qui" />
            )}
          </div>
        )}

        {activeTab === 'salute' && (
          <div style={{ marginTop: 12 }}>
            <SectionTitle>Trattamenti</SectionTitle>
            {gallinaTrattamenti.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {gallinaTrattamenti.map(t => (
                  <div key={t.id} className="card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>💊 {t.tipo}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{formatData(t.data)}</div>
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                      {t.prodotto && <div>Prodotto: {t.prodotto}</div>}
                      {t.dose && <div>Dose: {t.dose}</div>}
                      {t.note && <div>Note: {t.note}</div>}
                    </div>
                    {t.prossimo && (
                      <div style={{ marginTop: 8, padding: '6px 10px', background: '#FFE07A33', borderRadius: 8, fontSize: 12 }}>
                        📅 Prossimo trattamento: {formatData(t.prossimo)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState icon="💊" title="Nessun trattamento" subtitle="I trattamenti registrati appariranno qui" />
            )}

            <button className="btn-secondary" style={{ width: '100%', marginTop: 12 }}>
              <IconPlus size={16} /> Aggiungi trattamento
            </button>
          </div>
        )}
      </div>
    </React.Fragment>
  );
}

function AddChickenScreen({ onBack, onAdd }) {
  const [nome, setNome] = React.useState('');
  const [tipo, setTipo] = React.useState('gallina');
  const [razza, setRazza] = React.useState('');

  return (
    <React.Fragment>
      <Header title="Nuova gallina" onBack={onBack} />
      <ScreenContainer>
        <div style={{ textAlign: 'center', marginBottom: 20 }}>
          <div style={{ fontSize: 48 }}>{tipo === 'gallo' ? '🐓' : '🐣'}</div>
        </div>
        <FormField label="Nome">
          <input className="input" placeholder='Es. "Luna"' value={nome} onChange={e => setNome(e.target.value)} />
        </FormField>
        <FormField label="Tipo">
          <SegmentedControl options={[{ value: 'gallina', label: '🐔 Gallina' }, { value: 'gallo', label: '🐓 Gallo' }]}
            value={tipo} onChange={setTipo} />
        </FormField>
        <FormField label="Razza">
          <select className="input" value={razza} onChange={e => setRazza(e.target.value)}>
            <option value="">Scegli una razza...</option>
            {Object.keys(RAZZE).map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </FormField>

        {razza && RAZZE[razza] && RAZZE[razza].uovaAnno !== '—' && (
          <div className="card" style={{ background: 'var(--primary-lighter)', border: 'none' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--primary)', marginBottom: 6 }}>Info sulla razza</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, fontSize: 12, color: 'var(--text-secondary)' }}>
              <span>🥚 {RAZZE[razza].uovaAnno} uova/anno</span>
              <span>📏 Taglia {RAZZE[razza].taglia}</span>
            </div>
          </div>
        )}

        <FormField label="Data di nascita (approssimativa)">
          <input className="input" type="date" />
        </FormField>
        <FormField label="Colore piumaggio">
          <input className="input" placeholder="Es. bianca, rossa..." />
        </FormField>
        <FormField label="Note">
          <textarea className="input" rows="3" placeholder="Qualcosa da ricordare su questa gallina..."></textarea>
        </FormField>

        <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
          <button className="btn-secondary" style={{ flex: 1 }} onClick={onBack}>Annulla</button>
          <button className="btn-primary" style={{ flex: 2 }} onClick={() => onAdd && onAdd()} disabled={!nome.trim()}>
            Aggiungi {tipo === 'gallo' ? 'gallo' : 'gallina'}
          </button>
        </div>
      </ScreenContainer>
    </React.Fragment>
  );
}

Object.assign(window, { ChickensListScreen, ChickenDetailScreen, AddChickenScreen });
