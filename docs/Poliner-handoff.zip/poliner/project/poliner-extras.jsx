// poliner-extras.jsx — Maintenance, Weather, Menu, Expenses, Contacts, Notes, Shopping, Stats, Settings

// ─── MENU SCREEN ──────────────────────────────────────────
function MenuScreen({ onNavigate }) {
  const items = [
    { id: 'maintenance', label: 'Manutenzione', icon: '🧹', bg: '#B5D4B5', desc: 'Pulizie e interventi' },
    { id: 'weather', label: 'Meteo', icon: '⛅', bg: '#A8D1FF', desc: 'Previsioni e storico' },
    { id: 'expenses', label: 'Spese', icon: '💶', bg: '#FFE07A', desc: 'Registro e costi' },
    { id: 'contacts', label: 'Rubrica', icon: '👥', bg: '#FFE4D0', desc: 'Contatti e regali' },
    { id: 'notes', label: 'Note', icon: '📝', bg: '#E8DAFF', desc: 'Appunti e promemoria' },
    { id: 'shopping', label: 'Lista spesa', icon: '🛒', bg: '#FFD6E0', desc: 'Cose da comprare' },
    { id: 'stats', label: 'Statistiche', icon: '📊', bg: '#A8D1FF', desc: 'Grafici e analisi' },
    { id: 'settings', label: 'Impostazioni', icon: '⚙️', bg: '#F0EDE8', desc: 'Profilo e preferenze' },
  ];
  return (
    <React.Fragment>
      <Header title="Menu" />
      <ScreenContainer>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {items.map(item => (
            <div key={item.id} className="card card-clickable" onClick={() => onNavigate(item.id)}
              style={{ textAlign: 'center', padding: '20px 12px' }}>
              <div style={{ width: 48, height: 48, borderRadius: 16, background: item.bg + '44',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, margin: '0 auto 10px' }}>
                {item.icon}
              </div>
              <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text)' }}>{item.label}</div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{item.desc}</div>
            </div>
          ))}
        </div>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── MAINTENANCE ──────────────────────────────────────────
function MaintenanceScreen({ onBack }) {
  return (
    <React.Fragment>
      <Header title="Manutenzione" subtitle="Pulizie e interventi" onBack={onBack} />
      <ScreenContainer>
        <SectionTitle>Stato attuale</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {MANUTENZIONI_TIPI.map(tipo => {
            const stato = statoManutenzione(tipo.id);
            const giorni = giorniDaUltimaManutenzione(tipo.id);
            const rimanenti = tipo.frequenza - giorni;
            return (
              <div key={tipo.id} className="card" style={{
                borderLeft: `4px solid ${stato === 'scaduta' ? '#E8678A' : stato === 'in_scadenza' ? '#FFE07A' : '#B5D4B5'}`,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <span style={{ fontSize: 20 }}>{tipo.icona}</span>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{tipo.nome}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{tipo.dove} · Ogni {tipo.frequenza} giorni</div>
                    </div>
                  </div>
                </div>
                <div style={{ marginTop: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                    Ultimo: {giorni} giorni fa
                  </div>
                  {stato === 'scaduta' ? (
                    <Badge label={`⚠️ In ritardo di ${Math.abs(rimanenti)} gg`} bg="#FFD6E0" color="#c0435a" small />
                  ) : stato === 'in_scadenza' ? (
                    <Badge label={`🔔 Tra ${rimanenti} giorni`} bg="#FFE07A44" color="#8a7020" small />
                  ) : (
                    <Badge label={`✓ Tra ${rimanenti} giorni`} bg="#B5D4B533" color="#3d6b3d" small />
                  )}
                </div>
                {/* Progress bar */}
                <div style={{ marginTop: 6, height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(100, (giorni / tipo.frequenza) * 100)}%`, height: '100%',
                    background: stato === 'scaduta' ? '#E8678A' : stato === 'in_scadenza' ? '#FFE07A' : '#B5D4B5',
                    borderRadius: 2, transition: 'width 0.5s ease' }}></div>
                </div>
              </div>
            );
          })}
        </div>

        <SectionTitle>Ultimi interventi</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {MANUTENZIONI_LOG.sort((a, b) => b.data.localeCompare(a.data)).slice(0, 5).map(log => {
            const tipo = MANUTENZIONI_TIPI.find(t => t.id === log.tipo);
            return (
              <div key={log.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px' }}>
                <span style={{ fontSize: 18 }}>{tipo?.icona}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{tipo?.nome}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{formatData(log.data)}{log.note ? ` · ${log.note}` : ''}</div>
                </div>
              </div>
            );
          })}
        </div>

        <button className="btn-primary" style={{ width: '100%', marginTop: 16 }}>
          🧹 Registra intervento
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── WEATHER ──────────────────────────────────────────────
function WeatherScreen({ onBack }) {
  return (
    <React.Fragment>
      <Header title="Meteo" subtitle="Firenze, Toscana" onBack={onBack} />
      <ScreenContainer>
        {/* Current */}
        <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #A8D1FF22, #A8D1FF08)', marginTop: 4 }}>
          <div style={{ fontSize: 64 }}>{METEO.attuale.icona}</div>
          <div style={{ fontSize: 48, fontWeight: 800, color: 'var(--text)' }}>{METEO.attuale.temp}°C</div>
          <div style={{ fontSize: 15, color: 'var(--text-secondary)' }}>{METEO.attuale.condizione}</div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 20, marginTop: 16 }}>
            <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>💧 {METEO.attuale.umidita}%</div>
            <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>💨 {METEO.attuale.vento} km/h</div>
            <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>🌡️ Percepita {METEO.attuale.percepita}°</div>
          </div>
        </div>

        {/* Forecast */}
        <SectionTitle>Previsioni</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {METEO.previsioni.map((p, i) => (
            <div key={i} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ fontWeight: 600, fontSize: 14, width: 70 }}>{p.giorno}</div>
              <div style={{ display: 'flex', gap: 16 }}>
                {[{ label: 'Matt', data: p.mattina }, { label: 'Pom', data: p.pomeriggio }, { label: 'Sera', data: p.sera }].map(slot => (
                  <div key={slot.label} style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>{slot.label}</div>
                    <div style={{ fontSize: 18 }}>{slot.data.icona}</div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{slot.data.temp}°</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Weather tip */}
        {METEO.consiglio && (
          <div className="card" style={{ background: '#A8D1FF15', border: '1px solid #A8D1FF44', marginTop: 12 }}>
            <div style={{ fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>{METEO.consiglio}</div>
          </div>
        )}
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── EXPENSES ─────────────────────────────────────────────
function ExpensesScreen({ onBack }) {
  const totale = SPESE.reduce((s, sp) => s + sp.importo, 0);
  const totaleUova = UOVA.length;
  const costoPerUovo = totaleUova > 0 ? (totale / totaleUova).toFixed(2) : '—';
  return (
    <React.Fragment>
      <Header title="Registro spese" onBack={onBack} />
      <ScreenContainer>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 4 }}>
          <div className="card" style={{ textAlign: 'center', background: '#FFE07A22' }}>
            <div style={{ fontSize: 24, fontWeight: 800, color: 'var(--text)' }}>€{totale.toFixed(0)}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Totale spese</div>
          </div>
          <div className="card" style={{ textAlign: 'center', background: 'var(--primary-lighter)' }}>
            <div style={{ fontSize: 24, fontWeight: 800, color: 'var(--primary)' }}>€{costoPerUovo}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Costo per uovo</div>
          </div>
        </div>
        <div style={{ textAlign: 'center', fontSize: 12, color: 'var(--text-secondary)', margin: '6px 0 4px', fontStyle: 'italic' }}>
          Ogni uovo ti è costato circa €{costoPerUovo} 🥚
        </div>

        <SectionTitle>Ultime spese</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {SPESE.map(sp => (
            <div key={sp.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px' }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: '#FFE07A33',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>💶</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{sp.cosa}</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{formatData(sp.data)}{sp.note ? ` · ${sp.note}` : ''}</div>
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text)' }}>€{sp.importo.toFixed(2)}</div>
            </div>
          ))}
        </div>

        <button className="btn-primary" style={{ width: '100%', marginTop: 16 }}>
          💶 Aggiungi spesa
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── CONTACTS ─────────────────────────────────────────────
function ContactsScreen({ onBack }) {
  return (
    <React.Fragment>
      <Header title="Rubrica" subtitle="I tuoi contatti del pollaio" onBack={onBack} />
      <ScreenContainer>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
          {CONTATTI.sort((a, b) => b.totaleUova - a.totaleUova).map(c => (
            <div key={c.id} className="card card-clickable" style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Avatar name={c.nome} size={48} bg={['#FFE4D0','#E8DAFF','#A8D1FF','#FFD6E0'][c.id % 4]} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{c.nome}</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {c.relazione} · {c.totaleUova} uova regalate ({c.volte} volte)
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Ultimo regalo: {formatData(c.ultimaData)}</div>
              </div>
              <IconChevron size={18} color="var(--text-secondary)" />
            </div>
          ))}
        </div>
        <button className="btn-primary" style={{ width: '100%', marginTop: 16 }}>
          👤 Aggiungi contatto
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── NOTES ────────────────────────────────────────────────
function NotesScreen({ onBack }) {
  const tagColors = { osservazione: '#A8D1FF', idea: '#FFE07A', promemoria: '#E8DAFF' };
  const tagLabels = { osservazione: '👁️ Osservazione', idea: '💡 Idea', promemoria: '🔔 Promemoria' };
  return (
    <React.Fragment>
      <Header title="Note e promemoria" onBack={onBack} />
      <ScreenContainer>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
          {NOTE.map(n => (
            <div key={n.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <Badge label={tagLabels[n.tag] || n.tag} bg={(tagColors[n.tag] || '#F0EDE8') + '44'} color="var(--text)" small />
                <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{formatData(n.data)}</span>
              </div>
              <p style={{ fontSize: 14, color: 'var(--text)', lineHeight: 1.6, margin: 0 }}>{n.testo}</p>
              {n.promemoria && (
                <div style={{ marginTop: 8, padding: '6px 10px', background: '#E8DAFF22', borderRadius: 8, fontSize: 12, color: '#7b5ea7' }}>
                  🔔 Promemoria: {formatData(n.promemoria.data)} alle {n.promemoria.ora}
                </div>
              )}
            </div>
          ))}
        </div>
        <button className="btn-primary" style={{ width: '100%', marginTop: 16 }}>
          📝 Nuova nota
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── SHOPPING LIST ────────────────────────────────────────
function ShoppingScreen({ onBack }) {
  const [items, setItems] = React.useState(LISTA_SPESA);
  const toggle = (id) => {
    setItems(prev => prev.map(it => it.id === id ? { ...it, comprato: !it.comprato } : it));
  };
  const catColors = { cibo: '#FFE07A', lettiera: '#B5D4B5', medicinali: '#E8DAFF', altro: '#F0EDE8' };
  const pending = items.filter(i => !i.comprato);
  const done = items.filter(i => i.comprato);

  return (
    <React.Fragment>
      <Header title="Lista della spesa" subtitle={`${pending.length} da comprare`} onBack={onBack}
        right={<button className="btn-icon"><IconShare size={20} color="var(--text-secondary)" /></button>} />
      <ScreenContainer>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 4 }}>
          {pending.map(item => (
            <div key={item.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', cursor: 'pointer' }}
              onClick={() => toggle(item.id)}>
              <div style={{ width: 24, height: 24, borderRadius: 8, border: '2px solid var(--primary)', flexShrink: 0 }}></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{item.testo}</div>
              </div>
              <Badge label={item.categoria} bg={(catColors[item.categoria] || '#F0EDE8') + '44'} color="var(--text-secondary)" small />
            </div>
          ))}
        </div>

        {done.length > 0 && (
          <React.Fragment>
            <SectionTitle>Acquistati ✓</SectionTitle>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {done.map(item => (
                <div key={item.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', opacity: 0.5, cursor: 'pointer' }}
                  onClick={() => toggle(item.id)}>
                  <div style={{ width: 24, height: 24, borderRadius: 8, background: 'var(--primary)', flexShrink: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <IconCheck size={14} color="#fff" />
                  </div>
                  <div style={{ textDecoration: 'line-through', fontSize: 14 }}>{item.testo}</div>
                </div>
              ))}
            </div>
          </React.Fragment>
        )}

        <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
          <input className="input" placeholder="Aggiungi alla lista..." style={{ flex: 1 }} />
          <button className="btn-primary" style={{ padding: '10px 16px' }}><IconPlus size={18} /></button>
        </div>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── STATISTICS ───────────────────────────────────────────
function StatsScreen({ onBack }) {
  const [periodo, setPeriodo] = React.useState('mese');
  const totUova = UOVA.length;
  const totDisp = UOVA.filter(u => u.stato === 'disponibile').length;
  const totCons = UOVA.filter(u => u.stato === 'consumato').length;
  const totReg = UOVA.filter(u => u.stato === 'regalato').length;
  const totSpese = SPESE.reduce((s, sp) => s + sp.importo, 0);

  return (
    <React.Fragment>
      <Header title="Statistiche" onBack={onBack} />
      <div style={{ padding: '0 16px' }}>
        <SegmentedControl options={[
          { value: 'settimana', label: 'Settimana' },
          { value: 'mese', label: 'Mese' },
          { value: 'anno', label: 'Anno' },
        ]} value={periodo} onChange={setPeriodo} />
      </div>
      <ScreenContainer>
        {/* Overview cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 12 }}>
          <div className="card" style={{ textAlign: 'center', padding: '12px 6px' }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--primary)' }}>{totUova}</div>
            <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>Uova totali</div>
          </div>
          <div className="card" style={{ textAlign: 'center', padding: '12px 6px' }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#3d6b3d' }}>€{(totSpese / totUova).toFixed(2)}</div>
            <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>Costo/uovo</div>
          </div>
          <div className="card" style={{ textAlign: 'center', padding: '12px 6px' }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#7b5ea7' }}>{totReg}</div>
            <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>Regalate</div>
          </div>
        </div>

        {/* Production chart */}
        <SectionTitle>Produzione uova</SectionTitle>
        <div className="card">
          <MiniBarChart data={PRODUZIONE_SETTIMANE.map((s, i) => ({
            value: s.prodotte, label: s.settimana.replace('Sett ', ''),
            highlight: i >= PRODUZIONE_SETTIMANE.length - 2,
          }))} barColor="var(--primary)" height={72} />
          <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 8, textAlign: 'center' }}>
            Media: {Math.round(PRODUZIONE_SETTIMANE.reduce((s, w) => s + w.prodotte, 0) / PRODUZIONE_SETTIMANE.length)} uova/settimana
          </div>
        </div>

        {/* Destination donut */}
        <SectionTitle>Destinazione uova</SectionTitle>
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 16, justifyContent: 'center' }}>
          <DonutChart size={90} stroke={14} segments={[
            { value: totDisp, color: '#B5D4B5' },
            { value: totCons, color: '#FFE4D0' },
            { value: totReg, color: '#E8DAFF' },
          ]} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              { label: 'Disponibili', value: totDisp, color: '#B5D4B5' },
              { label: 'Consumate', value: totCons, color: '#FFE4D0' },
              { label: 'Regalate', value: totReg, color: '#E8DAFF' },
            ].map(s => (
              <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                <div style={{ width: 10, height: 10, borderRadius: 3, background: s.color }}></div>
                {s.label} ({s.value})
              </div>
            ))}
          </div>
        </div>

        {/* Per chicken production */}
        <SectionTitle>Per gallina (questa settimana)</SectionTitle>
        <div className="card">
          {GALLINE.filter(g => g.tipo === 'gallina').sort((a, b) => b.uovaSettimana - a.uovaSettimana).map(g => {
            const mx = 5;
            return (
              <div key={g.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span style={{ fontSize: 14, width: 70, fontWeight: 600 }}>{g.nome}</span>
                <div style={{ flex: 1, height: 14, background: 'var(--border)', borderRadius: 7, overflow: 'hidden' }}>
                  <div style={{ width: `${(g.uovaSettimana / mx) * 100}%`, height: '100%', background: g.avatarBg, borderRadius: 7 }}></div>
                </div>
                <span style={{ fontSize: 14, fontWeight: 700, width: 16, textAlign: 'right' }}>{g.uovaSettimana}</span>
              </div>
            );
          })}
        </div>

        {/* Expenses */}
        <SectionTitle>Spese mensili</SectionTitle>
        <div className="card">
          <MiniBarChart data={[
            { value: 28, label: 'Feb' }, { value: 49.5, label: 'Mar' },
            { value: 82, label: 'Apr' }, { value: 39.4, label: 'Mag' },
          ].map((d, i, arr) => ({ ...d, highlight: i === arr.length - 1 }))} barColor="#FFE07A" height={56} />
        </div>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────
function SettingsScreen({ onBack, onLogout }) {
  return (
    <React.Fragment>
      <Header title="Impostazioni" onBack={onBack} />
      <ScreenContainer>
        {/* Profile card */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 4 }}>
          <Avatar emoji="👩‍🌾" bg="#FFD6E0" size={56} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 17 }}>Francesca</div>
            <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>francesca@email.it</div>
          </div>
          <button className="btn-icon"><IconEdit size={18} color="var(--text-secondary)" /></button>
        </div>

        <SectionTitle>Il pollaio</SectionTitle>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            { label: 'Nome pollaio', value: 'Il Pollaio di Fiocca' },
            { label: 'Posizione', value: 'Firenze, Toscana' },
            { label: 'Nidi configurati', value: '3 nidi' },
          ].map(item => (
            <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{item.label}</span>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{item.value}</span>
            </div>
          ))}
        </div>

        <SectionTitle>Notifiche</SectionTitle>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {[
            { label: 'Manutenzione', on: true },
            { label: 'Uova in scadenza', on: true },
            { label: 'Meteo', on: true },
            { label: 'Promemoria', on: true },
            { label: 'Trattamenti', on: false },
          ].map(item => (
            <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14 }}>{item.label}</span>
              <div style={{
                width: 44, height: 26, borderRadius: 13, padding: 3, cursor: 'pointer',
                background: item.on ? 'var(--primary)' : 'var(--border)', transition: 'background 0.2s',
              }}>
                <div style={{
                  width: 20, height: 20, borderRadius: 10, background: '#fff',
                  transform: item.on ? 'translateX(18px)' : 'translateX(0)', transition: 'transform 0.2s',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
                }}></div>
              </div>
            </div>
          ))}
        </div>

        <SectionTitle>Conservazione uova</SectionTitle>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Temperatura ambiente</span>
            <span style={{ fontSize: 14, fontWeight: 600 }}>20 giorni</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>In frigorifero</span>
            <span style={{ fontSize: 14, fontWeight: 600 }}>28 giorni</span>
          </div>
        </div>

        <SectionTitle>Altro</SectionTitle>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {['Esporta dati', 'Informazioni app', 'Assistenza'].map(item => (
            <div key={item} className="card-clickable" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14 }}>{item}</span>
              <IconChevron size={16} color="var(--text-secondary)" />
            </div>
          ))}
        </div>

        <button className="btn-secondary" style={{ width: '100%', marginTop: 20, color: '#c0435a' }}
          onClick={onLogout}>
          Esci dall'account
        </button>

        <div style={{ textAlign: 'center', marginTop: 16, fontSize: 12, color: 'var(--text-secondary)' }}>
          Poliner v1.0 · Made with 🐔 in Italia
        </div>
      </ScreenContainer>
    </React.Fragment>
  );
}

// ─── NOTIFICATIONS ────────────────────────────────────────
function NotificationsScreen({ onBack, onNavigate }) {
  const [notifiche, setNotifiche] = React.useState([
    { id: 1, icon: '⚠️', title: 'Pulizia della casetta in ritardo', body: 'Sono passati 5 giorni dall\'ultima pulizia', time: '2 ore fa', letta: false, color: '#E8678A', action: 'maintenance' },
    { id: 2, icon: '🪶', title: 'Caramella è in muta', body: 'Da 20 giorni — è normale, la produzione riprenderà', time: '5 ore fa', letta: false, color: '#E8DAFF', action: 'chicken-detail' },
    { id: 3, icon: '❤️‍🩹', title: 'Artù ha un problema di salute', body: 'Ferite alle zampe — controlla il trattamento', time: 'Ieri', letta: false, color: '#E8678A', action: 'chicken-detail' },
    { id: 4, icon: '☀️', title: 'Domani bel tempo!', body: 'Giornata perfetta per far uscire le galline', time: 'Ieri', letta: true, color: '#A8D1FF' },
    { id: 5, icon: '🥚', title: 'Alcune uova stanno per scadere', body: 'Hai ancora 5 giorni per usarle o regalarle!', time: '2 giorni fa', letta: true, color: '#FFE07A', action: 'eggs' },
    { id: 6, icon: '💊', title: 'Trattamento antiparassitario in arrivo', body: 'Prossimo trattamento previsto per il 15 giugno', time: '3 giorni fa', letta: true, color: '#B5D4B5' },
    { id: 7, icon: '🌸', title: 'Consiglio di primavera', body: 'Le ore di luce aumentano: la produzione dovrebbe risalire!', time: '5 giorni fa', letta: true, color: '#B5D4B5' },
    { id: 8, icon: '🧹', title: 'Bagno di sabbia rinnovato', body: 'Registrato intervento — prossimo tra 14 giorni', time: '1 settimana fa', letta: true, color: '#B5D4B5' },
  ]);

  const nonLette = notifiche.filter(n => !n.letta).length;

  const segnaLetta = (id) => {
    setNotifiche(prev => prev.map(n => n.id === id ? { ...n, letta: true } : n));
  };
  const segnaTutteLette = () => {
    setNotifiche(prev => prev.map(n => ({ ...n, letta: true })));
  };

  return (
    <React.Fragment>
      <Header title="Notifiche" subtitle={nonLette > 0 ? `${nonLette} non lette` : 'Tutto letto ✓'} onBack={onBack}
        right={nonLette > 0 ? (
          <button className="btn-text" onClick={segnaTutteLette} style={{ fontSize: 13, whiteSpace: 'nowrap' }}>
            Segna tutte lette
          </button>
        ) : null}
      />
      <ScreenContainer>
        {notifiche.length === 0 ? (
          <EmptyState icon="🔔" title="Nessuna notifica" subtitle="Quando ci saranno avvisi, li troverai qui!" />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 4 }}>
            {notifiche.map(n => (
              <div key={n.id} className={`card ${n.action ? 'card-clickable' : ''}`}
                onClick={() => {
                  segnaLetta(n.id);
                  if (n.action) onNavigate(n.action, n.action === 'chicken-detail' ? (n.id === 2 ? 4 : 6) : null);
                }}
                style={{
                  display: 'flex', gap: 12, alignItems: 'flex-start',
                  background: n.letta ? '#fff' : 'var(--primary-lighter)',
                  borderLeft: n.letta ? '1px solid var(--border)' : `4px solid ${n.color}`,
                  opacity: n.letta ? 0.75 : 1,
                  transition: 'all 0.3s ease',
                }}>
                <span style={{ fontSize: 22, flexShrink: 0, marginTop: 2 }}>{n.icon}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                    <div style={{ fontWeight: n.letta ? 600 : 700, fontSize: 14, color: 'var(--text)' }}>{n.title}</div>
                    {!n.letta && <div style={{ width: 8, height: 8, borderRadius: 4, background: 'var(--primary)', flexShrink: 0, marginTop: 6 }}></div>}
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5, marginTop: 2 }}>{n.body}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}>{n.time}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScreenContainer>
    </React.Fragment>
  );
}

Object.assign(window, {
  MenuScreen, MaintenanceScreen, WeatherScreen, ExpensesScreen,
  ContactsScreen, NotesScreen, ShoppingScreen, StatsScreen, SettingsScreen,
  NotificationsScreen,
});
