// poliner-eggs.jsx — Eggs section (stock + add + gift)

function EggsScreen({ onNavigate }) {
  const [tab, setTab] = React.useState('scorte');
  const disponibili = UOVA.filter(u => u.stato === 'disponibile');
  const consumate = UOVA.filter(u => u.stato === 'consumato');
  const regalate = UOVA.filter(u => u.stato === 'regalato');

  // Group by date
  const byDate = {};
  disponibili.forEach(u => {
    if (!byDate[u.data]) byDate[u.data] = [];
    byDate[u.data].push(u);
  });
  const dates = Object.keys(byDate).sort((a, b) => b.localeCompare(a));

  return (
    <React.Fragment>
      <Header title="Le tue uova" subtitle={`${disponibili.length} disponibili`} />
      <div style={{ padding: '0 16px' }}>
        <SegmentedControl
          options={[{ value: 'scorte', label: 'Scorte' }, { value: 'storico', label: 'Storico' }, { value: 'statistiche', label: 'Grafici' }]}
          value={tab} onChange={setTab} />
      </div>
      <ScreenContainer>
        {tab === 'scorte' && (
          <div style={{ marginTop: 12 }}>
            {/* Summary cards */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 16 }}>
              <div className="card" style={{ textAlign: 'center', padding: '12px 8px', background: '#B5D4B520' }}>
                <div style={{ fontSize: 24, fontWeight: 800, color: '#3d6b3d' }}>{disponibili.length}</div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Disponibili</div>
              </div>
              <div className="card" style={{ textAlign: 'center', padding: '12px 8px', background: '#FFE4D030' }}>
                <div style={{ fontSize: 24, fontWeight: 800, color: '#b87333' }}>{consumate.length}</div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Consumate</div>
              </div>
              <div className="card" style={{ textAlign: 'center', padding: '12px 8px', background: '#E8DAFF30' }}>
                <div style={{ fontSize: 24, fontWeight: 800, color: '#7b5ea7' }}>{regalate.length}</div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Regalate</div>
              </div>
            </div>

            {/* Expiry warning */}
            {disponibili.filter(u => {
              const diff = Math.floor((new Date(u.data).getTime() + 20*24*60*60*1000 - oggi.getTime()) / (1000*60*60*24));
              return diff <= 5 && diff > 0;
            }).length > 0 && (
              <div className="card" style={{ background: '#FFE07A22', border: '1px solid #FFE07A66', marginBottom: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
                <span style={{ fontSize: 20 }}>⚠️</span>
                <div style={{ fontSize: 13, color: 'var(--text)' }}>
                  <strong>Alcune uova stanno per scadere</strong> — hai ancora qualche giorno per usarle o regalarle!
                </div>
              </div>
            )}

            {/* Eggs by date */}
            {dates.map(date => {
              const eggs = byDate[date];
              const daysAgo = Math.floor((oggi - new Date(date)) / (1000*60*60*24));
              const label = daysAgo === 0 ? 'Oggi' : daysAgo === 1 ? 'Ieri' : `${daysAgo} giorni fa`;
              return (
                <React.Fragment key={date}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '14px 0 8px' }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)' }}>{label} · {formatData(date)}</div>
                    <Badge label={`${eggs.length} 🥚`} bg="var(--primary-lighter)" color="var(--primary)" small />
                  </div>
                  <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                    {eggs.map((u, i) => (
                      <div key={u.id} style={{
                        display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px',
                        borderBottom: i < eggs.length - 1 ? '1px solid var(--border)' : 'none',
                      }}>
                        <span style={{ fontSize: 18 }}>🥚</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 14, fontWeight: 600 }}>{u.gallina}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{u.nido}</div>
                        </div>
                        {u.note && <span style={{ fontSize: 11, color: 'var(--text-secondary)', maxWidth: 100, textAlign: 'right' }}>{u.note}</span>}
                      </div>
                    ))}
                  </div>
                </React.Fragment>
              );
            })}

            <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
              <button className="btn-primary" style={{ flex: 1 }} onClick={() => onNavigate('add-egg')}>
                🥚 Aggiungi uovo
              </button>
              <button className="btn-secondary" style={{ flex: 1 }} onClick={() => onNavigate('gift-eggs')}>
                🎁 Regala uova
              </button>
            </div>
          </div>
        )}

        {tab === 'storico' && (
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {UOVA.sort((a, b) => b.data.localeCompare(a.data)).map(u => (
                <div key={u.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px' }}>
                  <span style={{ fontSize: 18 }}>🥚</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{u.gallina} · {formatData(u.data)}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                      {u.nido}{u.stato === 'regalato' ? ` · Regalato a ${u.regalatoA}` : ''}
                    </div>
                  </div>
                  <Badge
                    label={u.stato === 'disponibile' ? '✓' : u.stato === 'consumato' ? '🍳' : '🎁'}
                    bg={u.stato === 'disponibile' ? '#B5D4B533' : u.stato === 'consumato' ? '#F0EDE8' : '#FFE4D044'}
                    color={u.stato === 'disponibile' ? '#3d6b3d' : '#9E968C'}
                    small />
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'statistiche' && (
          <div style={{ marginTop: 12 }}>
            {/* Donut chart */}
            <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 20, justifyContent: 'center' }}>
              <DonutChart size={100} stroke={16} segments={[
                { value: disponibili.length, color: '#B5D4B5' },
                { value: consumate.length, color: '#FFE4D0' },
                { value: regalate.length, color: '#E8DAFF' },
              ]} />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                  <div style={{ width: 12, height: 12, borderRadius: 3, background: '#B5D4B5' }}></div>
                  Disponibili ({disponibili.length})
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                  <div style={{ width: 12, height: 12, borderRadius: 3, background: '#FFE4D0' }}></div>
                  Consumate ({consumate.length})
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                  <div style={{ width: 12, height: 12, borderRadius: 3, background: '#E8DAFF' }}></div>
                  Regalate ({regalate.length})
                </div>
              </div>
            </div>

            {/* Weekly bar chart */}
            <SectionTitle>Produzione settimanale</SectionTitle>
            <div className="card">
              <MiniBarChart
                data={PRODUZIONE_SETTIMANE.map((s, i) => ({
                  value: s.prodotte, label: s.settimana.replace('Sett ', 'S'),
                  highlight: i >= PRODUZIONE_SETTIMANE.length - 2,
                }))}
                barColor="var(--primary)" height={64}
              />
            </div>

            {/* Per chicken */}
            <SectionTitle>Produzione per gallina</SectionTitle>
            <div className="card">
              {GALLINE.filter(g => g.tipo === 'gallina').sort((a, b) => b.uovaSettimana - a.uovaSettimana).map(g => {
                const max = Math.max(...GALLINE.filter(g2 => g2.tipo === 'gallina').map(g2 => g2.uovaSettimana));
                return (
                  <div key={g.id} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                    <Avatar emoji={g.avatar} bg={g.avatarBg} size={28} />
                    <div style={{ fontSize: 13, fontWeight: 600, width: 70 }}>{g.nome}</div>
                    <div style={{ flex: 1, height: 12, background: 'var(--border)', borderRadius: 6, overflow: 'hidden' }}>
                      <div style={{ width: max > 0 ? `${(g.uovaSettimana / max) * 100}%` : '0%', height: '100%', background: g.avatarBg, borderRadius: 6, transition: 'width 0.5s ease' }}></div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', width: 20, textAlign: 'right' }}>{g.uovaSettimana}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </ScreenContainer>
    </React.Fragment>
  );
}

function AddEggScreen({ onBack, onAdd }) {
  const [gallina, setGallina] = React.useState('');
  const [nido, setNido] = React.useState('');
  const [note, setNote] = React.useState('');

  return (
    <React.Fragment>
      <Header title="Aggiungi uovo" onBack={onBack} />
      <ScreenContainer>
        <div style={{ textAlign: 'center', margin: '8px 0 20px' }}>
          <div style={{ fontSize: 56 }}>🥚</div>
          <div style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Chi ha fatto l'uovo?</div>
        </div>

        <FormField label="Gallina">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {GALLINE.filter(g => g.tipo === 'gallina').map(g => (
              <button key={g.id} className="card"
                onClick={() => setGallina(g.nome)}
                style={{
                  border: gallina === g.nome ? '2px solid var(--primary)' : '2px solid transparent',
                  background: gallina === g.nome ? 'var(--primary-lighter)' : '#fff',
                  cursor: 'pointer', textAlign: 'center', padding: '12px 8px',
                }}>
                <div style={{ fontSize: 24 }}>{g.avatar}</div>
                <div style={{ fontSize: 13, fontWeight: 600, marginTop: 4 }}>{g.nome}</div>
              </button>
            ))}
            <button className="card"
              onClick={() => setGallina('Non so')}
              style={{
                border: gallina === 'Non so' ? '2px solid var(--primary)' : '2px solid transparent',
                background: gallina === 'Non so' ? 'var(--primary-lighter)' : '#fff',
                cursor: 'pointer', textAlign: 'center', padding: '12px 8px',
              }}>
              <div style={{ fontSize: 24 }}>❓</div>
              <div style={{ fontSize: 13, fontWeight: 600, marginTop: 4 }}>Non so</div>
            </button>
          </div>
        </FormField>

        <FormField label="In quale nido?">
          <div style={{ display: 'flex', gap: 8 }}>
            {NIDI.map(n => (
              <button key={n.id} className="card"
                onClick={() => setNido(n.nome)}
                style={{
                  flex: 1, border: nido === n.nome ? '2px solid var(--primary)' : '2px solid transparent',
                  background: nido === n.nome ? 'var(--primary-lighter)' : '#fff',
                  cursor: 'pointer', textAlign: 'center', padding: '10px 6px',
                }}>
                <div style={{ fontSize: 18 }}>🪺</div>
                <div style={{ fontSize: 11, fontWeight: 600, marginTop: 4 }}>{n.nome.replace('Nido ', '')}</div>
              </button>
            ))}
          </div>
        </FormField>

        <FormField label="Data e ora">
          <input className="input" type="datetime-local" defaultValue="2026-05-18T10:30" />
        </FormField>

        <FormField label="Note (opzionale)">
          <input className="input" placeholder='Es. "guscio fragile", "uovo piccolo"' value={note} onChange={e => setNote(e.target.value)} />
        </FormField>

        <button className="btn-secondary" style={{ width: '100%', marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <IconCamera size={18} /> Aggiungi foto
        </button>

        <button className="btn-primary btn-lg" style={{ width: '100%' }} onClick={() => onAdd && onAdd()}>
          Registra uovo 🥚
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

function GiftEggsScreen({ onBack, onGift }) {
  const [qty, setQty] = React.useState(6);
  const [contatto, setContatto] = React.useState('');
  const disponibili = UOVA.filter(u => u.stato === 'disponibile').length;

  return (
    <React.Fragment>
      <Header title="Regala uova" onBack={onBack} />
      <ScreenContainer>
        <div style={{ textAlign: 'center', margin: '8px 0 20px' }}>
          <div style={{ fontSize: 56 }}>🎁</div>
        </div>

        <FormField label="Quante uova vuoi regalare?">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
            <button className="btn-icon" onClick={() => setQty(Math.max(1, qty - 1))}
              style={{ width: 44, height: 44, borderRadius: 22, background: 'var(--primary-lighter)', fontSize: 20 }}>−</button>
            <div style={{ fontSize: 40, fontWeight: 800, color: 'var(--primary)', minWidth: 50, textAlign: 'center' }}>{qty}</div>
            <button className="btn-icon" onClick={() => setQty(Math.min(disponibili, qty + 1))}
              style={{ width: 44, height: 44, borderRadius: 22, background: 'var(--primary-lighter)', fontSize: 20 }}>+</button>
          </div>
          <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>
            {disponibili} disponibili
          </div>
        </FormField>

        <FormField label="A chi?">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {CONTATTI.map(c => (
              <button key={c.id} className="card"
                onClick={() => setContatto(c.nome)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
                  border: contatto === c.nome ? '2px solid var(--primary)' : '2px solid transparent',
                  background: contatto === c.nome ? 'var(--primary-lighter)' : '#fff',
                }}>
                <Avatar name={c.nome} size={36} />
                <div style={{ flex: 1, textAlign: 'left' }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{c.nome}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{c.relazione} · {c.totaleUova} uova totali</div>
                </div>
              </button>
            ))}
          </div>
        </FormField>

        <button className="btn-primary btn-lg" style={{ width: '100%', marginTop: 8 }}
          onClick={() => onGift && onGift()} disabled={!contatto}>
          Regala {qty} uova a {contatto || '...'} 🎁
        </button>
      </ScreenContainer>
    </React.Fragment>
  );
}

Object.assign(window, { EggsScreen, AddEggScreen, GiftEggsScreen });
