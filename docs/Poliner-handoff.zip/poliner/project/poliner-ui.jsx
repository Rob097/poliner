// poliner-ui.jsx — Shared UI components + Icons for Poliner

// ─── ICONS ────────────────────────────────────────────────
const I = ({ d, size = 24, color = 'currentColor', ...p }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>{d}</svg>
);

const IconHome = (p) => <I {...p} d={<><path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"></path><path d="M9 21V12h6v9"></path></>} />;
const IconChicken = (p) => <I {...p} d={<><circle cx="12" cy="10" r="5"></circle><path d="M12 5V3"></path><path d="M10 3h4"></path><path d="M9 15l-2 6h10l-2-6"></path><path d="M8.5 9.5a1.5 1.5 0 100-3"></path></>} />;
const IconEgg = (p) => <I {...p} d={<ellipse cx="12" cy="13" rx="7" ry="8"></ellipse>} />;
const IconPlus = (p) => <I {...p} d={<><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></>} />;
const IconMenu = (p) => <I {...p} d={<><rect x="3" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="3" width="7" height="7" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect></>} />;
const IconBack = (p) => <I {...p} d={<><polyline points="15 18 9 12 15 6"></polyline></>} />;
const IconClose = (p) => <I {...p} d={<><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></>} />;
const IconCheck = (p) => <I {...p} d={<polyline points="4 12 9 17 20 6"></polyline>} />;
const IconChevron = (p) => <I {...p} d={<polyline points="9 6 15 12 9 18"></polyline>} />;
const IconSearch = (p) => <I {...p} d={<><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></>} />;
const IconCalendar = (p) => <I {...p} d={<><rect x="3" y="4" width="18" height="17" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></>} />;
const IconClock = (p) => <I {...p} d={<><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15 15"></polyline></>} />;
const IconCamera = (p) => <I {...p} d={<><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"></path><circle cx="12" cy="13" r="4"></circle></>} />;
const IconHeart = (p) => <I {...p} d={<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 000-7.78z"></path>} />;
const IconFeather = (p) => <I {...p} d={<><path d="M20.24 12.24a6 6 0 00-8.49-8.49L5 10.5V19h8.5z"></path><line x1="16" y1="8" x2="2" y2="22"></line><line x1="17.5" y1="15" x2="9" y2="15"></line></>} />;
const IconBell = (p) => <I {...p} d={<><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 01-3.46 0"></path></>} />;
const IconStar = (p) => <I {...p} d={<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>} />;
const IconGift = (p) => <I {...p} d={<><polyline points="20 12 20 22 4 22 4 12"></polyline><rect x="2" y="7" width="20" height="5"></rect><line x1="12" y1="22" x2="12" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z"></path></>} />;
const IconTrash = (p) => <I {...p} d={<><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"></path><path d="M10 11v6"></path><path d="M14 11v6"></path><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"></path></>} />;
const IconEdit = (p) => <I {...p} d={<><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"></path></>} />;
const IconPhone = (p) => <I {...p} d={<path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6A19.79 19.79 0 012.12 4.18 2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"></path>} />;
const IconSettings = (p) => <I {...p} d={<><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"></path></>} />;
const IconChart = (p) => <I {...p} d={<><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></>} />;
const IconNote = (p) => <I {...p} d={<><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></>} />;
const IconCart = (p) => <I {...p} d={<><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 01-8 0"></path></>} />;
const IconWrench = (p) => <I {...p} d={<><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"></path></>} />;
const IconUser = (p) => <I {...p} d={<><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></>} />;
const IconSun = (p) => <I {...p} d={<><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></>} />;
const IconWind = (p) => <I {...p} d={<><path d="M9.59 4.59A2 2 0 1111 8H2"></path><path d="M12.59 19.41A2 2 0 1014 16H2"></path><path d="M17.73 7.73A2.5 2.5 0 1119.5 12H2"></path></>} />;
const IconMap = (p) => <I {...p} d={<><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"></path><circle cx="12" cy="10" r="3"></circle></>} />;
const IconInfo = (p) => <I {...p} d={<><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></>} />;
const IconShare = (p) => <I {...p} d={<><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></>} />;

// ─── SHARED COMPONENTS ───────────────────────────────────

function Header({ title, subtitle, onBack, right, transparent }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
      background: transparent ? 'transparent' : 'var(--bg)',
      position: 'sticky', top: 0, zIndex: 20,
      borderBottom: transparent ? 'none' : '1px solid var(--border)',
    }}>
      {onBack && <button className="btn-icon" onClick={onBack}><IconBack size={22} /></button>}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'Lora, serif', fontWeight: 700, fontSize: 20, color: 'var(--text)', lineHeight: 1.2 }}>{title}</div>
        {subtitle && <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      {right}
    </div>
  );
}

function TabBar({ active, onNavigate, onFab }) {
  const tabs = [
    { id: 'home', label: 'Home', icon: IconHome },
    { id: 'chickens', label: 'Galline', icon: IconChicken },
    { id: 'fab', label: '', icon: null },
    { id: 'eggs', label: 'Uova', icon: IconEgg },
    { id: 'menu', label: 'Menu', icon: IconMenu },
  ];
  return (
    <div className="tab-bar">
      {tabs.map(tab => {
        if (tab.id === 'fab') {
          return (
            <button key="fab" className="fab-button" onClick={onFab} aria-label="Azione rapida">
              <IconPlus size={26} color="#fff" />
            </button>
          );
        }
        const Icon = tab.icon;
        const isActive = active === tab.id;
        return (
          <button key={tab.id} className={`tab-item ${isActive ? 'active' : ''}`} onClick={() => onNavigate(tab.id)}>
            <Icon size={22} color={isActive ? 'var(--primary)' : 'var(--text-secondary)'} />
            <span>{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function FABMenu({ onClose, onAction }) {
  const actions = [
    { id: 'add-egg', label: 'Aggiungi uovo', icon: '🥚', color: '#FFE4D0' },
    { id: 'add-cleaning', label: 'Segnala pulizia', icon: '🧹', color: '#B5D4B5' },
    { id: 'add-note', label: 'Nota rapida', icon: '📝', color: '#E8DAFF' },
  ];
  return (
    <div className="fab-overlay" onClick={onClose}>
      <div className="fab-menu" onClick={e => e.stopPropagation()}>
        {actions.map((a, i) => (
          <button key={a.id} className="fab-menu-item" onClick={() => { onAction(a.id); onClose(); }}
            style={{ animationDelay: `${i * 60}ms` }}>
            <span className="fab-menu-icon" style={{ background: a.color }}>{a.icon}</span>
            <span>{a.label}</span>
          </button>
        ))}
      </div>
      <button className="fab-button fab-close" onClick={onClose}>
        <IconClose size={24} color="#fff" />
      </button>
    </div>
  );
}

function Card({ children, onClick, style, className = '' }) {
  return (
    <div className={`card ${className} ${onClick ? 'card-clickable' : ''}`}
      onClick={onClick} style={style}>
      {children}
    </div>
  );
}

function Avatar({ emoji, bg, size = 48, name }) {
  if (emoji) {
    return (
      <div style={{ width: size, height: size, borderRadius: '50%', background: bg || '#FFD6E0',
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.5, flexShrink: 0 }}>
        {emoji}
      </div>
    );
  }
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: bg || 'var(--primary-light)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.4,
      fontWeight: 700, color: 'var(--primary)', flexShrink: 0 }}>
      {(name || '?')[0].toUpperCase()}
    </div>
  );
}

function Badge({ label, color, bg, small }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: small ? '2px 8px' : '3px 10px',
      borderRadius: 20, fontSize: small ? 11 : 12, fontWeight: 600,
      background: bg || 'var(--primary-light)', color: color || 'var(--primary)',
      whiteSpace: 'nowrap',
    }}>{label}</span>
  );
}

function Toast({ message, onClose }) {
  React.useEffect(() => {
    const t = setTimeout(onClose, 3000);
    return () => clearTimeout(t);
  }, []);
  return (
    <div className="toast-container">
      <div className="toast">{message}</div>
    </div>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-sheet" onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ fontFamily: 'Lora, serif', fontSize: 20, fontWeight: 700, margin: 0 }}>{title}</h3>
          <button className="btn-icon" onClick={onClose}><IconClose size={22} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function EmptyState({ icon, title, subtitle, action, onAction }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 32px' }}>
      <div style={{ fontSize: 56, marginBottom: 16 }}>{icon}</div>
      <div style={{ fontFamily: 'Lora, serif', fontSize: 18, fontWeight: 700, color: 'var(--text)', marginBottom: 8 }}>{title}</div>
      {subtitle && <div style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 20 }}>{subtitle}</div>}
      {action && <button className="btn-primary" onClick={onAction}>{action}</button>}
    </div>
  );
}

function StatNumber({ value, label, color, small }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: small ? 24 : 32, fontWeight: 800, color: color || 'var(--text)', fontFamily: 'Nunito, sans-serif', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: small ? 11 : 12, color: 'var(--text-secondary)', marginTop: 4 }}>{label}</div>
    </div>
  );
}

function AlertCard({ icon, title, subtitle, color, onClick }) {
  return (
    <div className="card card-clickable" onClick={onClick}
      style={{ display: 'flex', alignItems: 'center', gap: 12, borderLeft: `4px solid ${color || 'var(--primary)'}` }}>
      <span style={{ fontSize: 24 }}>{icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)' }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      <IconChevron size={18} color="var(--text-secondary)" />
    </div>
  );
}

function MiniBarChart({ data, maxVal, barColor, height = 48 }) {
  const mx = maxVal || Math.max(...data.map(d => d.value));
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
          <div style={{
            width: '100%', borderRadius: 3,
            height: mx > 0 ? Math.max(4, (d.value / mx) * height * 0.85) : 4,
            background: barColor || 'var(--primary)',
            opacity: d.highlight ? 1 : 0.5,
            transition: 'height 0.3s ease',
          }}></div>
          {d.label && <div style={{ fontSize: 9, color: 'var(--text-secondary)' }}>{d.label}</div>}
        </div>
      ))}
    </div>
  );
}

function DonutChart({ segments, size = 100, stroke = 14 }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const total = segments.reduce((s, seg) => s + seg.value, 0);
  let offset = 0;
  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--border)" strokeWidth={stroke} />
      {segments.map((seg, i) => {
        const pct = total > 0 ? seg.value / total : 0;
        const dash = pct * circ;
        const o = offset;
        offset += dash;
        return <circle key={i} cx={size/2} cy={size/2} r={r} fill="none" stroke={seg.color}
          strokeWidth={stroke} strokeDasharray={`${dash} ${circ - dash}`} strokeDashoffset={-o} />;
      })}
    </svg>
  );
}

function ScreenContainer({ children, pad = true }) {
  return (
    <div className="screen-scroll" style={{ padding: pad ? '0 16px 24px' : 0 }}>
      {children}
    </div>
  );
}

function SectionTitle({ children, right }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, marginBottom: 10 }}>
      <h3 style={{ fontFamily: 'Lora, serif', fontSize: 17, fontWeight: 700, color: 'var(--text)', margin: 0 }}>{children}</h3>
      {right}
    </div>
  );
}

function ListItem({ left, title, subtitle, right, onClick, badge }) {
  return (
    <div className="card card-clickable" onClick={onClick}
      style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      {left}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontWeight: 600, fontSize: 15, color: 'var(--text)' }}>{title}</span>
          {badge}
        </div>
        {subtitle && <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      {right || <IconChevron size={18} color="var(--text-secondary)" />}
    </div>
  );
}

function FormField({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      {label && <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6 }}>{label}</label>}
      {children}
    </div>
  );
}

function SegmentedControl({ options, value, onChange }) {
  return (
    <div style={{
      display: 'flex', background: 'var(--border)', borderRadius: 12, padding: 3, gap: 2,
    }}>
      {options.map(opt => (
        <button key={opt.value} onClick={() => onChange(opt.value)} style={{
          flex: 1, padding: '8px 12px', borderRadius: 10, border: 'none', fontSize: 13, fontWeight: 600,
          cursor: 'pointer', fontFamily: 'Nunito, sans-serif', transition: 'all 0.2s',
          background: value === opt.value ? '#fff' : 'transparent',
          color: value === opt.value ? 'var(--primary)' : 'var(--text-secondary)',
          boxShadow: value === opt.value ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
        }}>{opt.label}</button>
      ))}
    </div>
  );
}

// Logo component
function PolinerLogo({ size = 'md' }) {
  const sizes = { sm: { font: 18, egg: 16 }, md: { font: 28, egg: 24 }, lg: { font: 42, egg: 36 }, xl: { font: 56, egg: 48 } };
  const s = sizes[size] || sizes.md;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: s.egg * 0.3 }}>
      <svg width={s.egg} height={s.egg * 1.2} viewBox="0 0 40 48">
        <ellipse cx="20" cy="26" rx="16" ry="20" fill="#E8678A" />
        <ellipse cx="20" cy="24" rx="12" ry="15" fill="#FFD6E0" opacity="0.5" />
        <circle cx="15" cy="20" r="2" fill="#2E2924" />
        <path d="M18 26 Q20 29 22 26" stroke="#E8678A" strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M16 10 Q20 2 24 10" stroke="#E8678A" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      </svg>
      <span style={{ fontFamily: 'Lora, serif', fontWeight: 700, fontSize: s.font, color: 'var(--text)', letterSpacing: '-0.02em' }}>Poliner</span>
    </div>
  );
}

// Export all
Object.assign(window, {
  IconHome, IconChicken, IconEgg, IconPlus, IconMenu, IconBack, IconClose, IconCheck,
  IconChevron, IconSearch, IconCalendar, IconClock, IconCamera, IconHeart, IconFeather,
  IconBell, IconStar, IconGift, IconTrash, IconEdit, IconPhone, IconSettings, IconChart,
  IconNote, IconCart, IconWrench, IconUser, IconSun, IconWind, IconMap, IconInfo, IconShare,
  Header, TabBar, FABMenu, Card, Avatar, Badge, Toast, Modal, EmptyState, StatNumber,
  AlertCard, MiniBarChart, DonutChart, ScreenContainer, SectionTitle, ListItem,
  FormField, SegmentedControl, PolinerLogo,
});
