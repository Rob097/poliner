// poliner-data.jsx — Mock data for Poliner app

const RAZZE = {
  'Livornese (Leghorn)': { uovaAnno: '280–320', coloreUova: 'Bianche', taglia: 'Media', temperamento: 'Vivace, indipendente', inizioProduzione: 5, fineProduzione: 30 },
  'Rhode Island Red': { uovaAnno: '200–280', coloreUova: 'Marroni', taglia: 'Grande', temperamento: 'Docile, prolifica', inizioProduzione: 5, fineProduzione: 36 },
  'Padovana': { uovaAnno: '150–180', coloreUova: 'Bianche', taglia: 'Media', temperamento: 'Ornamentale, ciuffo, docile', inizioProduzione: 6, fineProduzione: 30 },
  'Sussex': { uovaAnno: '200–260', coloreUova: 'Crema/marroni', taglia: 'Grande', temperamento: 'Docile, curiosa', inizioProduzione: 5, fineProduzione: 36 },
  'Australorp': { uovaAnno: '250–300', coloreUova: 'Marroni', taglia: 'Grande', temperamento: 'Tranquilla, record di deposizione', inizioProduzione: 5, fineProduzione: 36 },
  'Araucana': { uovaAnno: '150–180', coloreUova: 'Blu-verdi/azzurre', taglia: 'Media', temperamento: 'Vivace, uova colorate', inizioProduzione: 6, fineProduzione: 30 },
  'Moroseta (Silkie)': { uovaAnno: '80–120', coloreUova: 'Crema', taglia: 'Nana', temperamento: 'Ornamentale, placidissima, cova bene', inizioProduzione: 7, fineProduzione: 24 },
  'Marans': { uovaAnno: '150–200', coloreUova: 'Bruno scuro/cioccolato', taglia: 'Grande', temperamento: 'Tranquilla, uova scurissime', inizioProduzione: 6, fineProduzione: 36 },
  'Orpington': { uovaAnno: '150–200', coloreUova: 'Crema/marroni', taglia: 'Grande', temperamento: 'Placida, ottima per famiglie', inizioProduzione: 6, fineProduzione: 36 },
  'ISA Brown': { uovaAnno: '280–310', coloreUova: 'Marroni rosate', taglia: 'Media', temperamento: 'Ibrida, molto produttiva', inizioProduzione: 4, fineProduzione: 24 },
  'Gallina mista': { uovaAnno: '—', coloreUova: '—', taglia: '—', temperamento: '—', inizioProduzione: 6, fineProduzione: 30 },
};

const COLORI_GALLINA = ['Bianca', 'Rossa', 'Nera', 'Camosciata', 'Grigia', 'Fulva', 'Blu', 'Millefiori', 'Sparviero', 'Multicolore'];

const GALLINE = [
  { id: 1, nome: 'Bianca', tipo: 'gallina', razza: 'Livornese (Leghorn)', dataNascita: '2024-03-15', colore: 'Bianca', note: 'La più produttiva del pollaio!', salute: 'ok', inMuta: false, uovaSettimana: 5, avatar: '🐔', avatarBg: '#FFE4D0' },
  { id: 2, nome: 'Rossella', tipo: 'gallina', razza: 'Rhode Island Red', dataNascita: '2024-09-20', colore: 'Rossa', note: 'Molto docile, si fa prendere in braccio', salute: 'ok', inMuta: false, uovaSettimana: 4, avatar: '🐔', avatarBg: '#FFD6E0' },
  { id: 3, nome: 'Pepita', tipo: 'gallina', razza: 'Padovana', dataNascita: '2023-06-10', colore: 'Camosciata', note: 'Bellissima con il ciuffo! Produce meno ma è ornamentale', salute: 'ok', inMuta: false, uovaSettimana: 2, avatar: '🐔', avatarBg: '#FFE07A' },
  { id: 4, nome: 'Caramella', tipo: 'gallina', razza: 'Sussex', dataNascita: '2025-04-01', colore: 'Bianca con collare nero', note: 'Curiosissima, viene sempre a vedere cosa fai', salute: 'ok', inMuta: true, inizioMuta: '2026-04-28', uovaSettimana: 0, avatar: '🪶', avatarBg: '#E8DAFF' },
  { id: 5, nome: 'Nerina', tipo: 'gallina', razza: 'Australorp', dataNascita: '2025-10-05', colore: 'Nera con riflessi verdi', note: 'Giovanissima, ha appena iniziato a deporre!', salute: 'ok', inMuta: false, uovaSettimana: 3, avatar: '🐔', avatarBg: '#B5D4B5' },
  { id: 6, nome: 'Artù', tipo: 'gallo', razza: 'Gallina mista', dataNascita: '2024-06-01', colore: 'Multicolore', note: 'Il re del pollaio! Un po\' prepotente ma bellissimo', salute: 'problema', problemaAttivo: 'Ferite alle zampe — beccato dalle galline', avatar: '🐓', avatarBg: '#A8D1FF', inMuta: false },
];

const NIDI = [
  { id: 1, nome: 'Nido Finestra', note: 'Il preferito di Bianca', uovaUltimaSettimana: 5 },
  { id: 2, nome: 'Nido Angolo', note: 'Più riparato, usato quando fa freddo', uovaUltimaSettimana: 4 },
  { id: 3, nome: 'Nido in Fondo', note: 'Poco usato ultimamente', uovaUltimaSettimana: 2 },
];

const oggi = new Date('2026-05-18');
function dataStr(d) { return d.toISOString().split('T')[0]; }
function giorniFA(n) { const d = new Date(oggi); d.setDate(d.getDate() - n); return d; }

const UOVA = [
  // Oggi
  { id: 1, data: dataStr(oggi), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'disponibile', note: '' },
  { id: 2, data: dataStr(oggi), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'disponibile', note: '' },
  { id: 3, data: dataStr(oggi), gallina: 'Nerina', nido: 'Nido Finestra', stato: 'disponibile', note: '' },
  // Ieri
  { id: 4, data: dataStr(giorniFA(1)), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'disponibile', note: '' },
  { id: 5, data: dataStr(giorniFA(1)), gallina: 'Pepita', nido: 'Nido in Fondo', stato: 'disponibile', note: 'Uovo un po\' piccolo' },
  { id: 6, data: dataStr(giorniFA(1)), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'disponibile', note: '' },
  // 2 giorni fa
  { id: 7, data: dataStr(giorniFA(2)), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'disponibile', note: '' },
  { id: 8, data: dataStr(giorniFA(2)), gallina: 'Nerina', nido: 'Nido Angolo', stato: 'disponibile', note: '' },
  { id: 9, data: dataStr(giorniFA(2)), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'consumato', note: '' },
  // 3 giorni fa
  { id: 10, data: dataStr(giorniFA(3)), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'disponibile', note: '' },
  { id: 11, data: dataStr(giorniFA(3)), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'disponibile', note: '' },
  { id: 12, data: dataStr(giorniFA(3)), gallina: 'Pepita', nido: 'Nido in Fondo', stato: 'consumato', note: '' },
  { id: 13, data: dataStr(giorniFA(3)), gallina: 'Nerina', nido: 'Nido Finestra', stato: 'disponibile', note: '' },
  // 4 giorni fa
  { id: 14, data: dataStr(giorniFA(4)), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'regalato', regalatoA: 'Nonna Maria', note: '' },
  { id: 15, data: dataStr(giorniFA(4)), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'regalato', regalatoA: 'Nonna Maria', note: '' },
  { id: 16, data: dataStr(giorniFA(4)), gallina: 'Nerina', nido: 'Nido Angolo', stato: 'regalato', regalatoA: 'Nonna Maria', note: '' },
  // 5 giorni fa
  { id: 17, data: dataStr(giorniFA(5)), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'consumato', note: '' },
  { id: 18, data: dataStr(giorniFA(5)), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'consumato', note: '' },
  // 6 giorni fa
  { id: 19, data: dataStr(giorniFA(6)), gallina: 'Bianca', nido: 'Nido Finestra', stato: 'regalato', regalatoA: 'Sara', note: '' },
  { id: 20, data: dataStr(giorniFA(6)), gallina: 'Pepita', nido: 'Nido in Fondo', stato: 'regalato', regalatoA: 'Sara', note: '' },
  { id: 21, data: dataStr(giorniFA(6)), gallina: 'Nerina', nido: 'Nido Finestra', stato: 'consumato', note: '' },
  { id: 22, data: dataStr(giorniFA(6)), gallina: 'Rossella', nido: 'Nido Angolo', stato: 'regalato', regalatoA: 'Sara', note: '' },
];

const CONTATTI = [
  { id: 1, nome: 'Nonna Maria', relazione: 'Nonna', telefono: '+39 333 1234567', note: 'Adora le uova fresche!', totaleUova: 24, volte: 5, ultimaData: '2026-05-14' },
  { id: 2, nome: 'Sara', relazione: 'Vicina di casa', telefono: '+39 340 9876543', note: 'Abita al piano di sotto', totaleUova: 15, volte: 4, ultimaData: '2026-05-12' },
  { id: 3, nome: 'Mamma', relazione: 'Mamma', telefono: '+39 328 5551234', note: '', totaleUova: 30, volte: 8, ultimaData: '2026-05-10' },
  { id: 4, nome: 'Zia Rosa', relazione: 'Zia', telefono: '+39 347 4445566', note: 'Preferisce le uova marroni', totaleUova: 8, volte: 2, ultimaData: '2026-04-20' },
];

const MANUTENZIONI_TIPI = [
  { id: 'pulizia_casetta', nome: 'Pulizia della casetta', dove: 'Casetta interna', frequenza: 7, icona: '🧹' },
  { id: 'pulizia_pollaio', nome: 'Pulizia completa del pollaio', dove: 'Tutto il recinto', frequenza: 14, icona: '🏠' },
  { id: 'cambio_trucciolo', nome: 'Cambio trucciolo', dove: 'Casetta interna', frequenza: 7, icona: '🪵' },
  { id: 'cambio_corteccia', nome: 'Cambio corteccia di pino', dove: 'Pollaio esterno', frequenza: 30, icona: '🌲' },
  { id: 'bagno_sabbia', nome: 'Rinnovo bagno di sabbia', dove: 'Area bagno', frequenza: 14, icona: '⏳' },
  { id: 'cambio_paglia', nome: 'Cambio paglia nei nidi', dove: 'Nidi', frequenza: 7, icona: '🌾' },
];

const MANUTENZIONI_LOG = [
  { id: 1, tipo: 'pulizia_casetta', data: dataStr(giorniFA(5)), note: 'Tutto pulito, cambiato anche il fondo' },
  { id: 2, tipo: 'cambio_trucciolo', data: dataStr(giorniFA(3)), note: '' },
  { id: 3, tipo: 'bagno_sabbia', data: dataStr(giorniFA(12)), note: 'Aggiunta terra di diatomea fresca' },
  { id: 4, tipo: 'cambio_corteccia', data: dataStr(giorniFA(25)), note: '' },
  { id: 5, tipo: 'cambio_paglia', data: dataStr(giorniFA(4)), note: '' },
  { id: 6, tipo: 'pulizia_pollaio', data: dataStr(giorniFA(10)), note: 'Pulizia generale, disinfettato il recinto' },
  { id: 7, tipo: 'pulizia_casetta', data: dataStr(giorniFA(12)), note: '' },
  { id: 8, tipo: 'cambio_trucciolo', data: dataStr(giorniFA(10)), note: 'Trucciolo tutto bagnato, cambiato prima del solito' },
];

const SPESE = [
  { id: 1, data: '2026-05-15', importo: 18.50, cosa: 'Mais e cereali', note: '2 sacchi' },
  { id: 2, data: '2026-05-10', importo: 12.00, cosa: 'Trucciolo pressato', note: '' },
  { id: 3, data: '2026-05-05', importo: 8.90, cosa: 'Terra di diatomea', note: 'Per il bagno di sabbia' },
  { id: 4, data: '2026-04-28', importo: 22.00, cosa: 'Pellet bio', note: 'Sacco grande' },
  { id: 5, data: '2026-04-15', importo: 45.00, cosa: 'Visita veterinario', note: 'Controllo zampe Artù' },
  { id: 6, data: '2026-04-05', importo: 15.00, cosa: 'Mais', note: '' },
  { id: 7, data: '2026-03-20', importo: 12.00, cosa: 'Trucciolo', note: '' },
  { id: 8, data: '2026-03-10', importo: 9.50, cosa: 'Paglia per nidi', note: '' },
  { id: 9, data: '2026-03-01', importo: 28.00, cosa: 'Mangime completo', note: 'Sacco 25kg' },
  { id: 10, data: '2026-02-15', importo: 18.00, cosa: 'Mais', note: '' },
];

const NOTE = [
  { id: 1, testo: 'Pepita sembra un po\' giù negli ultimi giorni, tenerla d\'occhio. Mangia meno del solito.', data: '2026-05-16', tag: 'osservazione', promemoria: null },
  { id: 2, testo: 'Provare a spostare il Nido in Fondo più in alto — forse è troppo basso e le galline non lo usano', data: '2026-05-14', tag: 'idea', promemoria: null },
  { id: 3, testo: 'Chiamare il veterinario per il controllo annuale', data: '2026-05-12', tag: 'promemoria', promemoria: { data: '2026-05-25', ora: '09:00', canale: 'push' } },
  { id: 4, testo: 'Oggi Nerina ha fatto il suo primo uovo! Emozione incredibile 🥚✨', data: '2026-04-10', tag: 'osservazione', promemoria: null },
];

const LISTA_SPESA = [
  { id: 1, testo: 'Mais (2 sacchi)', categoria: 'cibo', comprato: false },
  { id: 2, testo: 'Paglia per nidi', categoria: 'lettiera', comprato: false },
  { id: 3, testo: 'Corteccia di pino', categoria: 'lettiera', comprato: false },
  { id: 4, testo: 'Aceto di mele (integratore)', categoria: 'medicinali', comprato: true },
  { id: 5, testo: 'Mangime completo 25kg', categoria: 'cibo', comprato: false },
];

const METEO = {
  attuale: { temp: 22, percepita: 21, condizione: 'Parzialmente nuvoloso', icona: '⛅', vento: 12, umidita: 58 },
  previsioni: [
    { giorno: 'Oggi', mattina: { temp: 17, icona: '🌤️' }, pomeriggio: { temp: 24, icona: '⛅' }, sera: { temp: 19, icona: '🌙' } },
    { giorno: 'Domani', mattina: { temp: 16, icona: '☀️' }, pomeriggio: { temp: 26, icona: '☀️' }, sera: { temp: 20, icona: '🌤️' } },
    { giorno: 'Martedì', mattina: { temp: 18, icona: '🌧️' }, pomeriggio: { temp: 21, icona: '🌧️' }, sera: { temp: 17, icona: '🌧️' } },
  ],
  consiglio: '☀️ Domani splende il sole — giornata perfetta per far uscire le galline!'
};

const STAGIONALITA = {
  messaggio: 'Aumentano le ore di luce: la produzione delle uova dovrebbe riprendere a salire!',
  icona: '🌸',
  stagione: 'Primavera'
};

// Weekly egg production data (last 8 weeks)
const PRODUZIONE_SETTIMANE = [
  { settimana: 'Sett 11', prodotte: 16, consumate: 6, regalate: 4 },
  { settimana: 'Sett 12', prodotte: 18, consumate: 8, regalate: 6 },
  { settimana: 'Sett 13', prodotte: 15, consumate: 5, regalate: 4 },
  { settimana: 'Sett 14', prodotte: 19, consumate: 7, regalate: 6 },
  { settimana: 'Sett 15', prodotte: 17, consumate: 6, regalate: 5 },
  { settimana: 'Sett 16', prodotte: 14, consumate: 5, regalate: 3 },
  { settimana: 'Sett 17', prodotte: 16, consumate: 6, regalate: 4 },
  { settimana: 'Sett 18', prodotte: 11, consumate: 3, regalate: 6 },
];

const TRATTAMENTI = [
  { id: 1, data: '2026-05-10', tipo: 'Disinfezione ferita', animale: 'Artù', prodotto: 'Betadine veterinario', dose: 'Applicazione locale', note: 'Zampe posteriori', prossimo: '2026-05-17' },
  { id: 2, data: '2026-04-01', tipo: 'Sverminazione', animale: 'Tutto il pollaio', prodotto: 'Flubenvet', dose: '1 misurino nel mangime per 7 giorni', note: '', prossimo: '2026-10-01' },
  { id: 3, data: '2026-03-15', tipo: 'Antiparassitario', animale: 'Tutto il pollaio', prodotto: 'Terra di diatomea', dose: 'Spolverata su piumaggio', note: 'Preventivo', prossimo: '2026-06-15' },
];

// Helper functions
function calcolaEta(dataNascita) {
  const nascita = new Date(dataNascita);
  const diffMs = oggi - nascita;
  const mesi = Math.floor(diffMs / (1000 * 60 * 60 * 24 * 30.44));
  const anni = Math.floor(mesi / 12);
  const mesiResto = mesi % 12;
  if (anni === 0) return `${mesiResto} mesi`;
  if (mesiResto === 0) return `${anni} ann${anni === 1 ? 'o' : 'i'}`;
  return `${anni} ann${anni === 1 ? 'o' : 'i'} e ${mesiResto} mes${mesiResto === 1 ? 'e' : 'i'}`;
}

function faseProduttiva(gallina) {
  if (gallina.tipo === 'gallo') return null;
  const nascita = new Date(gallina.dataNascita);
  const mesi = Math.floor((oggi - nascita) / (1000 * 60 * 60 * 24 * 30.44));
  if (mesi < 5) return { fase: 'pollastra', label: 'Non ancora in deposizione', colore: '#A8D1FF' };
  if (mesi <= 24) return { fase: 'piena', label: 'Piena produzione', colore: '#B5D4B5' };
  if (mesi <= 36) return { fase: 'ridotta', label: 'Produzione in calo', colore: '#FFE07A' };
  return { fase: 'fine', label: 'Oltre il picco produttivo', colore: '#FFD6E0' };
}

function giorniDaUltimaManutenzione(tipoId) {
  const logs = MANUTENZIONI_LOG.filter(m => m.tipo === tipoId).sort((a, b) => new Date(b.data) - new Date(a.data));
  if (logs.length === 0) return 999;
  return Math.floor((oggi - new Date(logs[0].data)) / (1000 * 60 * 60 * 24));
}

function statoManutenzione(tipoId) {
  const tipo = MANUTENZIONI_TIPI.find(t => t.id === tipoId);
  const giorni = giorniDaUltimaManutenzione(tipoId);
  if (giorni >= tipo.frequenza) return 'scaduta';
  if (giorni >= tipo.frequenza - 2) return 'in_scadenza';
  return 'ok';
}

function formatData(dataStr) {
  const d = new Date(dataStr);
  const gg = d.getDate();
  const mesi = ['gen','feb','mar','apr','mag','giu','lug','ago','set','ott','nov','dic'];
  return `${gg} ${mesi[d.getMonth()]}`;
}

function formatDataLunga(dataStr) {
  const d = new Date(dataStr);
  const gg = d.getDate();
  const mesi = ['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
  return `${gg} ${mesi[d.getMonth()]} ${d.getFullYear()}`;
}

const uovaDisponibili = UOVA.filter(u => u.stato === 'disponibile').length;

// Export everything
Object.assign(window, {
  RAZZE, COLORI_GALLINA, GALLINE, NIDI, UOVA, CONTATTI,
  MANUTENZIONI_TIPI, MANUTENZIONI_LOG, SPESE, NOTE, LISTA_SPESA,
  METEO, STAGIONALITA, PRODUZIONE_SETTIMANE, TRATTAMENTI,
  calcolaEta, faseProduttiva, giorniDaUltimaManutenzione, statoManutenzione,
  formatData, formatDataLunga, uovaDisponibili, oggi, giorniFA, dataStr
});
