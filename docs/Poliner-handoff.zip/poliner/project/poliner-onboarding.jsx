// poliner-onboarding.jsx — Onboarding flow (5 steps)

function OnboardingScreen({ onComplete }) {
  const [step, setStep] = React.useState(0);
  const [pollaioName, setPollaioName] = React.useState('');
  const [location, setLocation] = React.useState('');
  const [chickenName, setChickenName] = React.useState('');
  const [chickenRazza, setChickenRazza] = React.useState('');
  const [chickenTipo, setChickenTipo] = React.useState('gallina');
  const [animating, setAnimating] = React.useState(false);

  const goNext = () => {
    setAnimating(true);
    setTimeout(() => { setStep(s => s + 1); setAnimating(false); }, 250);
  };
  const goBack = () => {
    setAnimating(true);
    setTimeout(() => { setStep(s => s - 1); setAnimating(false); }, 250);
  };

  const onbStyles = {
    page: { minHeight: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg-warm)', padding: '0 24px', },
    center: { flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center', padding: '24px 0', },
    title: { fontFamily: 'Lora, serif', fontSize: 26, fontWeight: 700, color: 'var(--text)', lineHeight: 1.3, marginBottom: 10, },
    subtitle: { fontSize: 15, color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: 300, },
    input: { width: '100%', padding: '14px 16px', borderRadius: 'var(--radius)', border: '2px solid var(--border)', fontSize: 16, fontFamily: 'Nunito, sans-serif', background: '#fff', outline: 'none', transition: 'border-color 0.2s', textAlign: 'center', },
    bottom: { padding: '16px 0 32px', display: 'flex', flexDirection: 'column', gap: 10, },
    dots: { display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 20, },
    illustration: { fontSize: 80, marginBottom: 24, lineHeight: 1, },
  };

  const dots = (
    <div style={onbStyles.dots}>
      {[0,1,2,3,4].map(i => (
        <div key={i} style={{
          width: i === step ? 24 : 8, height: 8, borderRadius: 4,
          background: i === step ? 'var(--primary)' : 'var(--border)',
          transition: 'all 0.3s ease',
        }}></div>
      ))}
    </div>
  );

  // Step 0: Welcome
  if (step === 0) return (
    <div style={onbStyles.page}>
      <div style={onbStyles.center}>
        <div style={onbStyles.illustration}>🐔</div>
        <PolinerLogo size="lg" />
        <div style={{ height: 16 }}></div>
        <p style={onbStyles.subtitle}>
          La memoria digitale del tuo pollaio.<br />
          Tutto in un posto solo, sempre a portata di mano.
        </p>
      </div>
      <div style={onbStyles.bottom}>
        {dots}
        <button className="btn-primary btn-lg" onClick={goNext}>Iniziamo!</button>
        <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)' }}>
          Ci vorranno solo 2 minuti ✨
        </p>
      </div>
    </div>
  );

  // Step 1: Name your coop
  if (step === 1) return (
    <div style={onbStyles.page}>
      {step > 0 && <div style={{ paddingTop: 12 }}><button className="btn-icon" onClick={goBack}><IconBack size={22} /></button></div>}
      <div style={onbStyles.center}>
        <div style={onbStyles.illustration}>🏡</div>
        <h2 style={onbStyles.title}>Come si chiama il tuo pollaio?</h2>
        <p style={{...onbStyles.subtitle, marginBottom: 24}}>Dagli un nome carino — sarà la tua casetta digitale</p>
        <input
          style={onbStyles.input}
          placeholder='Es. "Il Pollaio di Fiocca"'
          value={pollaioName}
          onChange={e => setPollaioName(e.target.value)}
          autoFocus
        />
      </div>
      <div style={onbStyles.bottom}>
        {dots}
        <button className="btn-primary btn-lg" onClick={goNext}
          disabled={!pollaioName.trim()}>
          Avanti
        </button>
      </div>
    </div>
  );

  // Step 2: Location
  if (step === 2) return (
    <div style={onbStyles.page}>
      <div style={{ paddingTop: 12 }}><button className="btn-icon" onClick={goBack}><IconBack size={22} /></button></div>
      <div style={onbStyles.center}>
        <div style={onbStyles.illustration}>📍</div>
        <h2 style={onbStyles.title}>Dove si trova?</h2>
        <p style={{...onbStyles.subtitle, marginBottom: 24}}>Ci serve per mostrarti il meteo e l'orario del tramonto</p>
        <input
          style={onbStyles.input}
          placeholder="Es. Firenze, Toscana"
          value={location}
          onChange={e => setLocation(e.target.value)}
        />
        <div style={{ height: 12 }}></div>
        <button className="btn-secondary" onClick={() => setLocation('Firenze, Toscana')} style={{ fontSize: 14 }}>
          <IconMap size={16} /> Usa la mia posizione
        </button>
      </div>
      <div style={onbStyles.bottom}>
        {dots}
        <button className="btn-primary btn-lg" onClick={goNext}
          disabled={!location.trim()}>Avanti</button>
      </div>
    </div>
  );

  // Step 3: Add photo (optional)
  if (step === 3) return (
    <div style={onbStyles.page}>
      <div style={{ paddingTop: 12 }}><button className="btn-icon" onClick={goBack}><IconBack size={22} /></button></div>
      <div style={onbStyles.center}>
        <div style={{
          width: 160, height: 160, borderRadius: 24, background: 'var(--primary-lighter)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24,
          border: '3px dashed var(--primary-light)',
        }}>
          <div style={{ textAlign: 'center' }}>
            <IconCamera size={40} color="var(--primary)" />
            <div style={{ fontSize: 13, color: 'var(--primary)', marginTop: 8, fontWeight: 600 }}>Aggiungi foto</div>
          </div>
        </div>
        <h2 style={onbStyles.title}>Una foto del pollaio?</h2>
        <p style={onbStyles.subtitle}>Opzionale — puoi aggiungerla anche dopo</p>
      </div>
      <div style={onbStyles.bottom}>
        {dots}
        <button className="btn-primary btn-lg" onClick={goNext}>Avanti</button>
        <button className="btn-text" onClick={goNext}>Salto per ora</button>
      </div>
    </div>
  );

  // Step 4: Add first chicken
  if (step === 4) return (
    <div style={onbStyles.page}>
      <div style={{ paddingTop: 12 }}><button className="btn-icon" onClick={goBack}><IconBack size={22} /></button></div>
      <div style={{ flex: 1, paddingTop: 16 }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🐣</div>
          <h2 style={{...onbStyles.title, fontSize: 22}}>Aggiungi la tua prima gallina!</h2>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Potrai aggiungerne altre dopo</p>
        </div>

        <FormField label="Nome">
          <input className="input" placeholder='Es. "Bianca"' value={chickenName}
            onChange={e => setChickenName(e.target.value)} />
        </FormField>

        <FormField label="Tipo">
          <SegmentedControl
            options={[{ value: 'gallina', label: '🐔 Gallina' }, { value: 'gallo', label: '🐓 Gallo' }]}
            value={chickenTipo} onChange={setChickenTipo}
          />
        </FormField>

        <FormField label="Razza">
          <select className="input" value={chickenRazza} onChange={e => setChickenRazza(e.target.value)}>
            <option value="">Scegli una razza...</option>
            {Object.keys(RAZZE).map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </FormField>

        {chickenRazza && RAZZE[chickenRazza] && RAZZE[chickenRazza].uovaAnno !== '—' && (
          <div className="card" style={{ background: 'var(--primary-lighter)', border: 'none', marginTop: 8 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--primary)', marginBottom: 6 }}>
              Info sulla razza {chickenRazza.split(' (')[0]}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, fontSize: 12, color: 'var(--text-secondary)' }}>
              <span>🥚 {RAZZE[chickenRazza].uovaAnno} uova/anno</span>
              <span>📏 Taglia {RAZZE[chickenRazza].taglia}</span>
              <span>🎨 Uova {RAZZE[chickenRazza].coloreUova}</span>
              <span>💛 {RAZZE[chickenRazza].temperamento}</span>
            </div>
          </div>
        )}
      </div>
      <div style={onbStyles.bottom}>
        {dots}
        <button className="btn-primary btn-lg" onClick={goNext}
          disabled={!chickenName.trim()}>
          Tutto pronto!
        </button>
      </div>
    </div>
  );

  // Step 5: Complete!
  return (
    <div style={onbStyles.page}>
      <div style={onbStyles.center}>
        <div style={{ fontSize: 80, marginBottom: 16, animation: 'bounce 0.6s ease' }}>🎉</div>
        <h2 style={{...onbStyles.title, fontSize: 28}}>Perfetto!</h2>
        <h3 style={{ fontFamily: 'Lora, serif', fontSize: 20, fontWeight: 600, color: 'var(--primary)', margin: '4px 0 16px' }}>
          {pollaioName || 'Il tuo pollaio'} è pronto
        </h3>
        <p style={onbStyles.subtitle}>
          {chickenName || 'La tua gallina'} ti aspetta! Ora puoi iniziare a registrare uova, pulizie e molto altro.
        </p>
        <div className="card" style={{ marginTop: 24, textAlign: 'left', width: '100%' }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 10 }}>Il tuo pollaio</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <span style={{ fontSize: 24 }}>🏡</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{pollaioName || 'Il mio pollaio'}</div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{location || 'Posizione non impostata'}</div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 24 }}>{chickenTipo === 'gallo' ? '🐓' : '🐔'}</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{chickenName || 'Gallina'}</div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{chickenRazza || 'Razza non specificata'}</div>
            </div>
          </div>
        </div>
      </div>
      <div style={onbStyles.bottom}>
        <button className="btn-primary btn-lg" onClick={onComplete}>
          Entra nel pollaio 🐔
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { OnboardingScreen });
